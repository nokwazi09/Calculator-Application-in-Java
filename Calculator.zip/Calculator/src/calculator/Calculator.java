/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;
import java.util.Scanner;
/**
 *
 * @author Jabulisile Khumalo
 */
public class Calculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner input=new Scanner(System.in);
       
       System.out.println("Welcome to my calcuator");
       System.out.println("Add numbers press 1");
       System.out.println(" Subtract numbers press 2");
       System.out.println("Muliply numbers press 3");
       System.out.println("Divide numbers press 4");
       
       int choice=input.nextInt();
       
       System.out.println("Enter first number:");
       double num1=input.nextDouble();
       
       System.out.println("Enter second number:");
       double num2=input.nextDouble();
       
       double result=0;
       boolean isValid=true;
       
       switch(choice){
           case 1:
             result=num1 + num2;
               break;
           case 2:
               result=num2- num1;
               break;
           case 3:
               result=num1 * num2;
               break;
           case 4:
               if (num2!=0){
               result=num1/num2;
               
       }else{
                   System.out.println("can not divide by zero!");
                   isValid=false;
               }
               break;
           default:
               System.out.println("invalid choice.");
               isValid=false;
    }
       if (isValid){
           if (result==(int)result){
               //if the result is a whole number,cast to in to remove.0
               System.out.println("Result:" +(int)result);
           }else{
               //if the result has decimals,print as it is 
               System.out.println("Result:"+ result);
           }
       }
    input.close();
}
}